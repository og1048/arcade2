import pygame
import asyncio
import sys

# Initialize Pygame
pygame.init()
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Web Pygame Hello World")

# Game Variables
box_x = 275
box_y = 175
box_speed = 5

# Pygbag requires everything to be inside an asynchronous main function
async def main():
    global box_x, box_y

    while True:
        # 1. Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # 2. Game Logic / Input Detection
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and box_x > 0:
            box_x -= box_speed
        if keys[pygame.K_RIGHT] and box_x < SCREEN_WIDTH - 50:
            box_x += box_speed

        # 3. Drawing
        screen.fill((30, 30, 40)) # Dark blue background
        
        # Draw a bright green square (our player)
        pygame.draw.rect(screen, (0, 255, 100), (box_x, box_y, 50, 50))

        # Refresh the screen
        pygame.display.flip()

        # 4. CRITICAL FOR WEB: Yield control to the browser frame rate
        await asyncio.sleep(0)

# Run the game
asyncio.run(main())
