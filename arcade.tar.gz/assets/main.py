import pygame
import asyncio
import sys
import random

# 1. Initialize Pygame
pygame.init()

# Define grid sizing
TILE_SIZE = 40
MAZE = [
    "############",
    "#D...#.....#",
    "####.#.###.#",
    "#....#...#.#",
    "#.######.#.#",
    "#......#.#.#",
    "#.####.#.#.#",
    "#.#..#.#.#.#",
    "#.#.##.###.#",
    "#.........E#",
    "############"
]

# Calculate screen size automatically based on the maze layout
SCREEN_WIDTH = len(MAZE[0]) * TILE_SIZE
SCREEN_HEIGHT = len(MAZE) * TILE_SIZE
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Dragon Maze Adventure")

# Load and scale egg image (place this after screen initialization)
egg_image = pygame.image.load("doug.png")  # Replace with your actual image path
egg_image = pygame.transform.scale(egg_image, (TILE_SIZE, TILE_SIZE))
# Colors
COLOR_BG = (20, 15, 25)       # Dark purple haze
COLOR_WALL = (70, 50, 90)     # Mystic stone walls
COLOR_DRAGON = (255, 60, 60)  # Fire Red Dragon
COLOR_GOAL = (255, 215, 0)    # Golden Egg
COLOR_TEXT = (255, 255, 255)  # White

# Parse maze to find starting positions & build collision boxes
walls = []
dragon_x, dragon_y = 0, 0
goal_rect = None

for row_index, row in enumerate(MAZE):
    for col_index, tile in enumerate(row):
        x = col_index * TILE_SIZE
        y = row_index * TILE_SIZE
        if tile == "#":
            walls.append(pygame.Rect(x, y, TILE_SIZE, TILE_SIZE))
        elif tile == "D":
            dragon_x, dragon_y = x + 5, y + 5 # Small padding to fit inside tiles
        elif tile == "E":
            goal_rect = pygame.Rect(x + 5, y + 5, TILE_SIZE - 10, TILE_SIZE - 10)

# Dragon details (making it slightly smaller than tiles to slide through gaps easily)
dragon_size = TILE_SIZE - 10
dragon_speed = 1
game_won = False
egg_speed = 1
egg_dir_x, egg_dir_y = random.choice([(-1, 0), (1, 0), (0, -1), (0, 1)])

player_image = pygame.image.load("dad.png")  # Replace with your actual player image path
player_image = pygame.transform.scale(player_image, (dragon_size, dragon_size))


# Font configuration for the win text
font = pygame.font.SysFont(None, 40)

async def main():
    global dragon_x, dragon_y, game_won, egg_dir_x, egg_dir_y

    while True:
        # ---- 1. EVENT HANDLING ----
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # ---- 2. GAME LOGIC & MOVEMENT ----
        if not game_won:
            keys = pygame.key.get_pressed()
            
            # Store old positions to revert back if the dragon hits a wall
            old_x = dragon_x
            old_y = dragon_y

            if keys[pygame.K_LEFT]:
                dragon_x -= dragon_speed
            if keys[pygame.K_RIGHT]:
                dragon_x += dragon_speed
            if keys[pygame.K_UP]:
                dragon_y -= dragon_speed
            if keys[pygame.K_DOWN]:
                dragon_y += dragon_speed

            # Create a hit-box for the dragon's current position
            dragon_rect = pygame.Rect(dragon_x, dragon_y, dragon_size, dragon_size)

            # Collision Detection: If dragon overlaps any wall, undo that frame's movement
            for wall in walls:
                if dragon_rect.colliderect(wall):
                    dragon_x = old_x
                    dragon_y = old_y
                    break
# ---- Egg Random Movement ----
            old_egg_x = goal_rect.x
            old_egg_y = goal_rect.y
            
            # Move egg in its current direction
            goal_rect.x += egg_dir_x * egg_speed
            goal_rect.y += egg_dir_y * egg_speed
            
            # If egg hits a wall, undo movement and pick a completely new random direction
            egg_hit_wall = False
            for wall in walls:
                if goal_rect.colliderect(wall):
                    egg_hit_wall = True
                    break
            
            if egg_hit_wall:
                goal_rect.x = old_egg_x
                goal_rect.y = old_egg_y
                egg_dir_x, egg_dir_y = random.choice([(-1, 0), (1, 0), (0, -1), (0, 1)])
            # Occasionally change direction anyway so it doesn't just bounce back and forth
            elif random.random() < 0.003: 
                egg_dir_x, egg_dir_y = random.choice([(-1, 0), (1, 0), (0, -1), (0, 1)])
                
            # Check if dragon reached the Golden Egg
            if dragon_rect.colliderect(goal_rect):
                game_won = True

        # ---- 3. DRAWING THE SCREEN ----
        screen.fill(COLOR_BG)

        # Draw Walls
        for wall in walls:
            pygame.draw.rect(screen, COLOR_WALL, wall, border_radius=4)

        # Draw Goal (Golden Egg)
        screen.blit(egg_image, (goal_rect.x - 5, goal_rect.y - 5))

        # Draw Player (Dragon - Red block with small wing accents)
        screen.blit(player_image, (dragon_x, dragon_y))
        
        # Display Win Screen Overlay
        if game_won:
            text_surface = font.render("Hurray! RagDag Cuddle", True, COLOR_TEXT)
            # Center the text background card
            text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            pygame.draw.rect(screen, (0, 0, 0), text_rect.inflate(30, 20)) # background shadow box
            screen.blit(text_surface, text_rect)

        # Refresh Display
        pygame.display.flip()

        # ---- 4. FRAME DELAY FOR WEB ----
        await asyncio.sleep(0)

# Start execution
asyncio.run(main())
